﻿// JScript File

// Dummy file for playing with the ScriptManager