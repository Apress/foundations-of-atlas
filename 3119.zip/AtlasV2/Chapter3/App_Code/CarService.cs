using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;


/// <summary>
/// Summary description for CarService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class CarService : System.Web.Services.WebService {

    public CarService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public int GetCarValue(string strCarMake,
                           string strCarModel,
                           int strCarYear)
    {
        int nReturn = 0;
        if (strCarMake == "Honda")
            nReturn = 30000;
        else
            nReturn = 20000;
        if (strCarModel == "Pilot")
            nReturn += 10000;

        int nDepreciation =
          (System.DateTime.Now.Year - strCarYear) * 2000;
        nReturn -= nDepreciation;
        return Math.Max(0, nReturn);
    }

    
}

