﻿ASP.NET "Atlas"
==============================================
Date: 4/6/2006

License: Please refer to the accompanying EULA.RTF file for the license agreement and information on using "Atlas".

The "Atlas" project templates and project items contain the assemblies to get started. All code, templates, samples, and documentation related to "Atlas" are a very early technical preview and are therefore subject to change.

Many thanks,

-- The Web Platform and Tools Team


More Resources:
==============================================
Further updates, samples, and other documents are available on the "Atlas" Web site (http://atlas.asp.net).

Please use the ASP.NET forums to post questions and bug reports. "Atlas" team members are actively engaged in the forum.

"Atlas" Discussions and Suggestions:
	http://forums.asp.net/1007/ShowForum.aspx

"Atlas" UI:
	http://forums.asp.net/1008/ShowForum.aspx

"Atlas" Networking and Services:
	http://forums.asp.net/1009/ShowForum.aspx

