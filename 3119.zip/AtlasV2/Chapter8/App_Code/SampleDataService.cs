using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Web;
using System.Web.Caching;
using System.Web.Services;
using System.Web.Services.Protocols;
using Microsoft.Web.Services;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class SampleDataService : DataService
{
    static List<SampleRow> _data;
    static int _nextId;
    static object _dataLock = new object();

    private static List<SampleRow> Data
    {
        get
        {
            if (_data == null)
            {
                lock (_dataLock)
                {
                    if (_data == null)
                    {
                        _data = new List<SampleRow>();
                        _data.Add(new SampleRow(0, "A. Datum Corporation",
                          "http://www.adatum.com"));
                        _data.Add(new SampleRow(1, "Adventure Works",
                          "http://www.adventure-works.com"));
                        _data.Add(new SampleRow(2, "Alpine Ski House",
                          "http://www.alpineskihouse.com"));
                        _data.Add(new SampleRow(3, "Baldwin Museum of Science�",
                          "http://www.baldwinmuseumofscience.com"));
                        _data.Add(new SampleRow(4, "Blue Yonder Airlines",
                          "http://www.blueyonderairlines.com"));
                        _data.Add(new SampleRow(5, "City Power & Light",
                          "http://www.cpandl.com"));
                        _data.Add(new SampleRow(6, "Coho Vineyard",
                          "http://www.cohovineyard.com"));
                        _data.Add(new SampleRow(7, "Contoso, Ltd",
                          "http://www.contoso.com"));
                        _data.Add(new SampleRow(8, "Graphic Design Institute",
                          "http://www.graphicdesigninstitute.com"));
                        _nextId = 9;
                    }
                }
            }
            return _data;
        }
    }

    [DataObjectMethod(DataObjectMethodType.Delete)]
    public void DeleteRow(int id)
    {
        foreach (SampleRow row in _data)
        {
            if (row.Id == id)
            {
                lock (_dataLock)
                {
                    _data.Remove(row);
                }
                break;
            }
        }
    }

    [DataObjectMethod(DataObjectMethodType.Select)]
    public SampleRow[] SelectRows()
    {
        return SampleDataService.Data.ToArray();
    }

    [DataObjectMethod(DataObjectMethodType.Insert)]
    public SampleRow InsertRow(string organization, string url)
    {
        SampleRow newRow;
        lock (_dataLock)
        {
            newRow = new SampleRow(_nextId++, organization, url);
            _data.Add(newRow);
        }
        return newRow;
    }

    [DataObjectMethod(DataObjectMethodType.Update)]
    public void UpdateRow(SampleRow updateRow)
    {
        foreach (SampleRow row in _data)
        {
            if (row.Id == updateRow.Id)
            {
                row.Name = updateRow.Name;
                row.Description = updateRow.Description;
                break;
            }
        }
    }
}


public class SampleRow
{
  private string _name;
  private string _description;
  private int _id;

  [DataObjectField(true, true)]
  public int Id
  {
    get { return _id; }
    set { _id = value; }
  }

  [DataObjectField(false)]
  [DefaultValue("New row")]
  public string Name
  {
    get { return _name; }
    set { _name = value; }
  }

  [DataObjectField(false)]
  [DefaultValue("")]
  public string Description
  {
    get { return _description; }
    set { _description = value; }
  }

  public SampleRow()
  {
    _id = -1;
  }

  public SampleRow(int id, string name, string description)
  {
    _id = id;
    _name = name;
    _description = description;
  }
}



