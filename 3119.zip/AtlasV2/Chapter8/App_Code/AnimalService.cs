using System;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace Quickstart.Samples.Data
{
    public class Animal
    {
        String _name;
        String _category;
        String _color;
        
        public String Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public String Category
        {
            get { return _category; }
            set { _category = value; }
        }
        
        public String Color
        {
            get { return _color; }
            set { _color = value; }
        }

        public Animal(String name, String category, String color)
        {
            _name = name;
            _category = category;
            _color = color;
        }
    };    
    
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class AnimalService : System.Web.Services.WebService
    {
        [WebMethod]
        public string[] GetCompletionList(string prefixText, int count)
        {
            prefixText = prefixText.ToLower();
            string[] categories = {
                "Cat",
                "Dog",
                "Cow",
                "Parrot",
            };
            
            List<string> suggestions = new List<string>();
            foreach (string category in categories)
            {
                if (category.ToLower().StartsWith(prefixText))
                {
                    suggestions.Add(category);
                }
            }
            return suggestions.ToArray();
        }        
        
        [WebMethod]
        public Animal[] GetAnimals(String searchText)
        {
            List<Animal> _data = GetAllAnimals();

            if (String.IsNullOrEmpty(searchText))
            {
                return _data.ToArray();
            }

            List<Animal> _dataFiltered = new List<Animal>();
            foreach (Animal animal in _data)
            {
                if (searchText.ToLower().CompareTo(animal.Category.ToLower()) == 0)
                    _dataFiltered.Add(animal);
            }

            return _dataFiltered.ToArray();
        }

        List<Animal> GetAllAnimals()
        {
            List<Animal> _data = new List<Animal>();

            _data.Add(new Animal("Felix", "Cat", "Grey"));
            _data.Add(new Animal("Fido", "Dog", "Brown"));
            _data.Add(new Animal("Rover", "Dog", "Brown"));
            _data.Add(new Animal("Daisy", "Cow", "Black and White"));
            _data.Add(new Animal("Polly", "Parrot", "Green"));

            return _data;
        }       
    }
}

