﻿// JScript File

Type.registerNamespace("AtlasBook");

AtlasBook.IStickShift = function() {
    this.setGear = Function.abstractMethod;
    this.getGear = Function.abstractMethod;
    this.getGearCount = Function.abstractMethod;
}
AtlasBook.IStickShift.registerInterface('AtlasBook.IStickShift');


AtlasBook.Car = function(strMake, strModel, strYear) {
    var m_Make = strMake;
    var m_Model = strModel;
    var m_Year = strYear;
    
    this.getMake = function() {
        return m_Make;
    }
    
    this.getModel = function() {
        return m_Model;
    }
    
    this.getMakeandModel = function() {
        return m_Make + ' ' + m_Model;
    }
    
    this.getYear = function() {
        return m_Year;
    }

    this.dispose = function() {
        alert('bye ' + this.getName());
    }
}
AtlasBook.Car.registerAbstractClass('AtlasBook.Car');


AtlasBook.SUV=function(strMake, strModel, strYear, strDriveType)
{
    AtlasBook.SUV.initializeBase(this,[strMake,strModel,strYear]);
    var m_DriveType = strDriveType;
    this.getDriveType = function() {
        return m_DriveType;
    }
}
AtlasBook.SUV.registerClass('AtlasBook.SUV', AtlasBook.Car);

AtlasBook.SportsCar=function(strMake, strModel, strYear, strGears)
{
    AtlasBook.SportsCar.initializeBase(this,[strMake, strModel, strYear]);
    var m_Gears = strGears;
    var m_CurrentGear = 0;
    this.setGear = function(strGearToSet){
        m_CurrentGear = strGearToSet;
        return true;
    }
    this.getGear = function(){
        return m_CurrentGear;
    }
    this.getGearCount = function(){
        return m_Gears;
    }
}
AtlasBook.SportsCar.registerAbstractClass('AtlasBook.SportsCar', AtlasBook.Car, AtlasBook.IStickShift);

AtlasBook.CheapSportsCar = function(strMake, strModel, strYear, strGears)
{
    AtlasBook.SportsCar.initializeBase(this,[strMake, strModel, strYear]);
}
AtlasBook.CheapSportsCar.registerClass('AtlasBook.CheapSportsCar', AtlasBook.Car);

