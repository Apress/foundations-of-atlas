using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;


/// <summary>
/// Summary description for wordlst
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class wordlst : System.Web.Services.WebService {

    public wordlst () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }
    [WebMethod]
    public string[] GetWordList()
    {
        String[] theWordList = new String[6];
        theWordList[0] = "Bob";
        theWordList[1] = "Bobby";
        theWordList[2] = "Bobbette";
        theWordList[3] = "Bobbit";
        theWordList[4] = "Bobbles";
        theWordList[5] = "Boba Fett";
        return theWordList;

    }
}

