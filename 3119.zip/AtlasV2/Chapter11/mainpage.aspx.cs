using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Xml;

public partial class mainpage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DoUpdate();
    }
    private String GetPriceHistoryText(string strTicker)
    {
        DataTier theData = new DataTier();
        DataTable theTable = theData.GetFullPriceHistory(strTicker, 300);
        StringBuilder theHTML = new StringBuilder();
        theHTML.Append("<table>");
        int nRows = theTable.Rows.Count;
        for (int i = 1; i < nRows; i++)
        {
            theHTML.Append("<tr><td width='100px'>");
            theHTML.Append(theTable.Rows[i].ItemArray[0].ToString());
            theHTML.Append("</td><td width='100px'>");
            theHTML.Append(theTable.Rows[i].ItemArray[1].ToString());
            theHTML.Append("</td></tr>");
        }
        theHTML.Append("</table>");
        return theHTML.ToString();
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        DoUpdate();
        
    }

    private void GetCompanyInfo(string strTicker)
    {
        // Note that the web service at flash-db tends to go down a lot. if it does, you'll get a 403 error here
        companyInfo.CompanyInfoService x = new companyInfo.CompanyInfoService();
        companyInfo.CompanyInfoResult y = x.doCompanyInfo("anything", "anything", strTicker);
        lblQuote.Text = y.company + " Current Price: " + y.lastPrice;
    }
    private void DoUpdate()
    {
        lblPH.Text = GetPriceHistoryText(TextBox1.Text);
        GetCompanyInfo(TextBox1.Text);
        lblPHGraph.Text = "<img src='PH.aspx?ticker=" + TextBox1.Text + "&days=100' />";
        lblAnalyticGraph.Text = "<img src='PHBB.aspx?ticker=" + TextBox1.Text + "&days=100' />";
        lblMoreQuote.Text = "";
    }
    protected void btnMore_Click(object sender, EventArgs e)
    {
        GetExtendedQuote(TextBox1.Text);
    }

    private void GetNewsItems(string strTicker)
    {
    }
    private void GetExtendedQuote(string strTicker)
    {
        // Note that the web service at flash-db tends to go down a lot. if it does, you'll get a 403 error here
        companyInfo.CompanyInfoService x = new companyInfo.CompanyInfoService();
        companyInfo.CompanyInfoResult y = x.doCompanyInfo("anything", "anything", strTicker);
        StringBuilder theHTML = new StringBuilder();
        theHTML.Append("<table width='100%' cellspacing='0' cellpadding='0' style='border-width: 0'>");
        theHTML.Append("<tr><td  width='40%'>");
        theHTML.Append("Bid ");
        theHTML.Append("</td><td  width='40%'>");
        theHTML.Append(y.bid);
        theHTML.Append("</td></tr>");
        
        theHTML.Append("<tr><td  width='40%'>");
        theHTML.Append("Ask ");
        theHTML.Append("</td><td  width='40%'>");
        theHTML.Append(y.ask);
        theHTML.Append("</td></tr>");

        theHTML.Append("<tr><td  width='40%'>");
        theHTML.Append("Open ");
        theHTML.Append("</td><td  width='40%'>");
        theHTML.Append(y.open);
        theHTML.Append("</td></tr>");

        theHTML.Append("<tr><td  width='40%'>");
        theHTML.Append("Year High ");
        theHTML.Append("</td><td  width='40%'>");
        theHTML.Append(y.yearHigh);
        theHTML.Append("</td></tr>");

        theHTML.Append("<tr><td  width='40%'>");
        theHTML.Append("Year Low ");
        theHTML.Append("</td><td  width='40%'>");
        theHTML.Append(y.yearLow);
        theHTML.Append("</td></tr>");

        theHTML.Append("</table>");
        lblMoreQuote.Text = theHTML.ToString();
        
        
    }
    protected void quoteTimer_tick(object sender, EventArgs e)
    {
        GetCompanyInfo(TextBox1.Text);
    }
}
